import streamlit as st
import pandas as pd
import os
from io import BytesIO

# 📁 ปรับตาม path จริงของคุณ
BUDGET_TYPE_PATHS = {
    "งบทั้งหมด": "C:/Users/CFF7204/Desktop/Excel Filter/งบทั้งหมด",
    "งบกลาง": "C:/Users/CFF7204/Desktop/Excel Filter/งบกลาง",
    "งบกองทุน": "C:/Users/CFF7204/Desktop/Excel Filter/งบกองทุน",
    "งบปกติ": "C:/Users/CFF7204/Desktop/Excel Filter/งบปกติ"
}

def clean_zone_value(val):
    try:
        return str(int(float(str(val).strip())))
    except:
        return None

def filter_by_zones(df, zone_col, selected_zones):
    def zone_match(x):
        try:
            val = str(int(float(str(x))))
            return val in selected_zones
        except:
            return False
    return df[df[zone_col].apply(zone_match)]

# 🌟 เริ่มต้นหน้า App
st.set_page_config(page_title="Excel เขต Filter", layout="wide")
st.markdown("<h1 style='font-size:60px;'>📊 โปรแกรมกรองข้อมูล สสท.</h1>", unsafe_allow_html=True)
("โปรแกรมที่สามารถกรองข้อมูล สารมารถเลือกดูตามปี และตามเขต")

# 🔲 สร้าง layout 3 คอลัมน์
col1, col2, col3 = st.columns(3)

with col1:
    budget_type = st.selectbox("✅ เลือกประเภทงบ", list(BUDGET_TYPE_PATHS.keys()))

if budget_type:
    budget_path = BUDGET_TYPE_PATHS[budget_type]

    if not os.path.exists(budget_path):
        st.error(f"❌ ไม่พบโฟลเดอร์: {budget_path}")
    else:
        years = [f for f in os.listdir(budget_path) if os.path.isdir(os.path.join(budget_path, f))]
        with col2:
            selected_year = st.selectbox("📅 เลือกปี", years)

        if selected_year:
            year_folder = os.path.join(budget_path, selected_year)
            files = [f for f in os.listdir(year_folder) if f.endswith(".xlsx")]

            with col3:
                selected_file = st.selectbox("📗 เลือกไฟล์ Excel", files)

            if selected_file:
                file_path = os.path.join(year_folder, selected_file)
                xls = pd.ExcelFile(file_path)
                sheet_names = xls.sheet_names

                # 👇 วาง selectbox ชีตไว้ด้านล่าง (ไม่อยู่ใน columns)
                selected_sheet = st.selectbox("🧾 เลือกชีต", sheet_names)

                if selected_sheet:
                    found_zone_column = False

                    for header_row in [2, 3, 4, 5]:
                        try:
                            df = xls.parse(selected_sheet, header=header_row)
                            df.columns = df.columns.astype(str)

                            zone_col = next((
                                col for col in df.columns
                                if col.strip() in ["สทบ", "เขต", "สทบ. เขต", "สทบ.เขต"]
                                or ("สทบ" in col and "เขต" in col)
                            ), None)

                            if zone_col:
                                st.success(f"✅ พบคอลัมน์เขต: {zone_col} (จาก header row {header_row})")

                                zones_raw = df[zone_col].dropna().unique()
                                zones_cleaned = [clean_zone_value(z) for z in zones_raw]
                                zones_cleaned = sorted(set(filter(None, zones_cleaned)), key=lambda x: int(x))

                                # ✅ Checkbox เลือกทุกเขต
                                select_all = st.checkbox("✅ เลือกทุกเขต")
                                if select_all:
                                    selected_zones = zones_cleaned
                                else:
                                    selected_zones = st.multiselect("📍 เลือกเขต", zones_cleaned)

                                if selected_zones:
                                    matches = filter_by_zones(df, zone_col, selected_zones)
                                    matches.insert(0, "Sheet", selected_sheet)

                                    if not matches.empty:
                                        st.success(f"📈 พบข้อมูล {len(matches)} แถว")
                                        st.dataframe(matches)

                                        output = BytesIO()
                                        matches.to_excel(output, index=False, engine="openpyxl")
                                        st.download_button(
                                            label="⬇️ ดาวน์โหลดผลลัพธ์",
                                            data=output.getvalue(),
                                            file_name=f"ผลลัพธ์เขต{'_'.join(selected_zones)}_{selected_sheet}.xlsx",
                                            mime="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet"
                                        )
                                    else:
                                        st.warning("❗ ไม่พบข้อมูลที่ตรงกับเขตที่เลือก")
                                found_zone_column = True
                                break
                        except:
                            continue

                    if not found_zone_column:
                        st.error("❗ ไม่พบคอลัมน์ 'เขต' ที่ใช้งานได้ในชีตนี้")
